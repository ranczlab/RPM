#pragma once

namespace TeensyStep
{
    constexpr const char* version = "V2.1";
    constexpr const char* branch = "master";
} // namespace TeensyStep