OptiMouse

Original code by Martijn The
Modified by zapmaker to (a) run on Arduino 1.x and (b) support 2620 sensor

Hack an older or cheaper optical mouse to read data from it.
Note: Newer optical mice have complex chips that cannot be read by this library.
Look at the libraries and search on the web to find mice that have these sensors.