#! /bin/bash
cd /home/pi/corridor
for value in {1}
do
	godot -d Level.tscn -w -t &
	sleep 5
	res=$(xdotool search --onlyvisible --name Corridor)
	xdotool windowsize $res 2560 800
	xdotool windowmove $res 0 0
	#echo -e $res
	#echo $value
done
